import type { SVGProps } from 'react';

export function AquaGuardLogo(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M3 12c.83.98 1.83 1.8 3 2.5 1.17.7 2.5.98 4 1 .5.02 1.5.02 2 0 1.5-.02 2.83-.3 4-1 1.17-.7 2.17-1.52 3-2.5" />
      <path d="M3 6c.83.98 1.83 1.8 3 2.5 1.17.7 2.5.98 4 1 .5.02 1.5.02 2 0 1.5-.02 2.83-.3 4-1 1.17-.7 2.17-1.52 3-2.5" />
      <path d="M3 18c.83.98 1.83 1.8 3 2.5 1.17.7 2.5.98 4 1 .5.02 1.5.02 2 0 1.5-.02 2.83-.3 4-1 1.17-.7 2.17-1.52 3-2.5" />
    </svg>
  );
}
