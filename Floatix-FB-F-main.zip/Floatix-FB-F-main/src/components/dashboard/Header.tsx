'use client';

import { AquaGuardLogo } from '@/components/icons/AquaGuardLogo';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import { Button } from '@/components/ui/button';
import { PhoneIncoming, MapPin } from 'lucide-react';

interface HeaderProps {
  onSetGps: () => void;
}

export default function Header({ onSetGps }: HeaderProps) {
  const userImage = PlaceHolderImages.find(p => p.id === 'user-avatar');

  return (
    <header className="sticky top-0 z-50 w-full border-b border-white/10 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-14 max-w-screen-2xl items-center justify-between">
        <div className="flex items-center gap-3">
          <AquaGuardLogo className="h-7 w-7 text-orange-500" />
          <h1 className="text-xl font-bold tracking-tight text-orange-500 font-headline">
            Floatix
          </h1>
        </div>

        <div className="flex items-center gap-4">
          <Button variant="destructive" size="sm" className="hidden sm:flex animate-pulse">
            <PhoneIncoming className="mr-2 h-4 w-4" />
            INCOMING SOS
          </Button>
          <Button variant="outline" size="sm" className="hidden sm:flex" onClick={onSetGps}>
            <MapPin className="mr-2 h-4 w-4" />
            Set GPS
          </Button>
          <p className="hidden text-sm text-muted-foreground sm:block">Operator: Unit 734</p>
          <Avatar>
            {userImage && <AvatarImage src={userImage.imageUrl} alt="User Avatar" data-ai-hint={userImage.imageHint} />}
            <AvatarFallback>U7</AvatarFallback>
          </Avatar>
        </div>
      </div>
    </header>
  );
}
