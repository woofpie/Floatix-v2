'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import React from "react";
import { useRealtimeData } from "../../hooks/useRealtimeData";
import {
  HeartPulse,
  Thermometer,
  Droplets,
  Move,
  Gauge,
  Battery,
  Wifi,
  Signal,
} from 'lucide-react';
import { cn } from '@/lib/utils';

// 🩺 Realtime Data Connected Version
export default function LiveVitals() {
  const { data, loading, error } = useRealtimeData();

  if (loading) {
    return <div className="text-center text-gray-400 p-4">Loading live data...</div>;
  }

  if (error) {
    return <div className="text-center text-red-500 p-4">Error: {error}</div>;
  }

  // 🧩 Map Firebase data fields (from your Realtime DB)
  const vitals = {
    heartRate: data?.pulse ?? 0,
    spo2: data?.spo2 ?? 98,              // placeholder or connect when available
    temperature: data?.tempC ?? 0,
    motorSpeed: data?.motorSpeed ?? 0,
    battery: data?.battery ?? 0,
    connectivity: data?.connectivity ?? 'online',
    acceleration: {
      x: data?.accX ?? 0,
      y: data?.accY ?? 0,
      z: data?.accZ ?? 0,
    },
  };

  // ♻ VitalCard component
  const VitalCard = ({
    icon: Icon,
    title,
    value,
    unit,
    children,
    iconClassName
  }: {
    icon: React.ElementType;
    title: string;
    value?: string | number;
    unit?: string;
    children?: React.ReactNode;
    iconClassName?: string;
  }) => (
    <Card className="transition-all hover:shadow-lg hover:shadow-primary/10 border-white/10 bg-black/20">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">{title}</CardTitle>
        <Icon className={cn("h-4 w-4 text-muted-foreground", iconClassName)} />
      </CardHeader>
      <CardContent>
        {value !== undefined && (
          <div className="text-4xl font-bold">
            {value}
            {unit && <span className="text-sm text-muted-foreground">{unit}</span>}
          </div>
        )}
        {children}
      </CardContent>
    </Card>
  );

  // 📶 Connectivity indicator
  const ConnectivityIndicator = ({ status }: { status: string }) => {
    const color =
      status === 'online'
        ? 'text-green-500'
        : status === 'weak'
        ? 'text-yellow-500'
        : 'text-red-500';
    const text = status ? status.charAt(0).toUpperCase() + status.slice(1) : 'Offline';

    return (
      <div className="flex items-center gap-2 pt-2">
        <Signal className={cn('h-5 w-5', color)} />
        <span className={cn('text-lg font-medium', color)}>{text}</span>
      </div>
    );
  };

  // 🖥 Render dashboard vitals
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      <VitalCard
        icon={HeartPulse}
        title="Heart Rate"
        value={vitals.heartRate.toFixed(0)}
        unit=" bpm"
        iconClassName="text-chart-1"
      />
      <VitalCard
        icon={Droplets}
        title="SpO₂"
        value={vitals.spo2.toFixed(0)}
        unit=" %"
        iconClassName="text-chart-2"
      />
      <VitalCard
        icon={Thermometer}
        title="Body Temp"
        value={vitals.temperature.toFixed(1)}
        unit=" °C"
        iconClassName="text-chart-3"
      />
      <VitalCard
        icon={Gauge}
        title="Motor Speed"
        value={Math.round(vitals.motorSpeed)}
        unit=" km/h"
        iconClassName="text-chart-4"
      />
      <Card className="border-white/10 bg-black/20">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">Battery</CardTitle>
          <Battery className="h-4 w-4 text-primary" />
        </CardHeader>
        <CardContent>
          <div className="mb-2 flex items-baseline gap-2">
            <span className="text-4xl font-bold">{vitals.battery.toFixed(0)}</span>
            <span className="text-sm font-medium text-muted-foreground">%</span>
          </div>
          <Progress value={vitals.battery} className="h-2" />
        </CardContent>
      </Card>
      <VitalCard icon={Wifi} title="Connectivity">
        <ConnectivityIndicator status={vitals.connectivity} />
      </VitalCard>
      <VitalCard
        icon={Move}
        title="Acceleration"
        iconClassName="text-primary"
      >
        <div className="flex justify-around text-center text-lg pt-2">
          <div>
            <div className="font-bold">{vitals.acceleration.x.toFixed(2)}</div>
            <div className="text-xs text-muted-foreground">X</div>
          </div>
          <div>
            <div className="font-bold">{vitals.acceleration.y.toFixed(2)}</div>
            <div className="text-xs text-muted-foreground">Y</div>
          </div>
          <div>
            <div className="font-bold">{vitals.acceleration.z.toFixed(2)}</div>
            <div className="text-xs text-muted-foreground">Z</div>
          </div>
        </div>
      </VitalCard>
    </div>
  );
}