'use client';

import { APIProvider, Map, AdvancedMarker } from '@vis.gl/react-google-maps';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { MapPin } from 'lucide-react';

interface GpsMapProps {
  position: { lat: number; lng: number };
}

const API_KEY = "AIzaSyBMszvsNnr5fOs3KnPVwcEeAk--SxIsQ7Q";

const mapStyle = [
    { elementType: "geometry", stylers: [{ color: "#242f3e" }] },
    { elementType: "labels.text.stroke", stylers: [{ color: "#242f3e" }] },
    { elementType: "labels.text.fill", stylers: [{ color: "#746855" }] },
    {
      featureType: "administrative.locality",
      elementType: "labels.text.fill",
      stylers: [{ color: "#d59563" }],
    },
    {
      featureType: "poi",
      elementType: "labels.text.fill",
      stylers: [{ color: "#d59563" }],
    },
    {
      featureType: "poi.parks",
      elementType: "geometry",
      stylers: [{ color: "#263c3f" }],
    },
    {
      featureType: "poi.parks",
      elementType: "labels.text.fill",
      stylers: [{ color: "#6b9a76" }],
    },
    {
      featureType: "road",
      elementType: "geometry",
      stylers: [{ color: "#38414e" }],
    },
    {
      featureType: "road",
      elementType: "geometry.stroke",
      stylers: [{ color: "#212a37" }],
    },
    {
      featureType: "road",
      elementType: "labels.text.fill",
      stylers: [{ color: "#9ca5b3" }],
    },
    {
      featureType: "road.highway",
      elementType: "geometry",
      stylers: [{ color: "#746855" }],
    },
    {
      featureType: "road.highway",
      elementType: "geometry.stroke",
      stylers: [{ color: "#1f2835" }],
    },
    {
      featureType: "road.highway",
      elementType: "labels.text.fill",
      stylers: [{ color: "#f3d19c" }],
    },
    {
      featureType: "transit",
      elementType: "geometry",
      stylers: [{ color: "#2f3948" }],
    },
    {
      featureType: "transit.station",
      elementType: "labels.text.fill",
      stylers: [{ color: "#d59563" }],
    },
    {
      featureType: "water",
      elementType: "geometry",
      stylers: [{ color: "#17263c" }],
    },
    {
      featureType: "water",
      elementType: "labels.text.fill",
      stylers: [{ color: "#515c6d" }],
    },
    {
      featureType: "water",
      elementType: "labels.text.stroke",
      stylers: [{ color: "#17263c" }],
    },
  ];

export default function GpsMap({ position }: GpsMapProps) {
  if (!API_KEY) {
    return (
        <Card className="border-white/10 bg-black/20">
            <CardHeader>
                <CardTitle className="font-headline">GPS Location</CardTitle>
            </CardHeader>
            <CardContent>
                <div className="flex h-[400px] items-center justify-center rounded-lg bg-muted text-muted-foreground">
                    <p>Google Maps API Key not configured.</p>
                </div>
            </CardContent>
        </Card>
    );
  }

  return (
    <Card className="border-white/10 bg-black/20">
        <CardHeader>
            <CardTitle className="font-headline">GPS Location</CardTitle>
        </CardHeader>
        <CardContent>
            <div className="h-[400px] w-full overflow-hidden rounded-lg">
            <APIProvider apiKey={API_KEY}>
                <Map
                    key={`${position.lat}-${position.lng}`}
                    mapId="aquaguard-map"
                    styles={mapStyle}
                    style={{ width: '100%', height: '100%' }}
                    defaultCenter={position}
                    defaultZoom={15}
                    gestureHandling={'greedy'}
                    disableDefaultUI={true}
                >
                <AdvancedMarker position={position} >
                    <MapPin className="h-8 w-8 text-primary animate-pulse" />
                </AdvancedMarker>
                </Map>
            </APIProvider>
            </div>
      </CardContent>
    </Card>
  );
}
