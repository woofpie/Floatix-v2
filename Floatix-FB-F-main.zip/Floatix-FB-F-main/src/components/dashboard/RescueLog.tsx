'use client';

import type { RescueLog as RescueLogType } from '@/lib/types';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { ScrollArea } from '@/components/ui/scroll-area';
import { formatDistanceToNow } from 'date-fns';

interface RescueLogProps {
  logs: RescueLogType[];
}

export default function RescueLog({ logs }: RescueLogProps) {
  return (
    <Card className="border-white/10 bg-black/20">
      <CardHeader>
        <div className="flex items-center justify-between">
            <div>
                <CardTitle className="font-headline">Rescue & Victim Registry</CardTitle>
                <CardDescription>
                A log of all rescue operations.
                </CardDescription>
            </div>
            <div className="text-right">
                <div className="text-3xl font-bold text-primary">{logs.length}</div>
                <div className="text-xs text-muted-foreground">Rescued</div>
            </div>
        </div>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[340px]">
          <Table>
            <TableHeader>
              <TableRow className="border-white/10">
                <TableHead>ID</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Time of Rescue</TableHead>
                <TableHead className="text-right">Vitals</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {logs.map((log) => (
                <TableRow key={log.id} className="border-white/10">
                  <TableCell className="font-medium">{log.id}</TableCell>
                  <TableCell>{log.name}</TableCell>
                  <TableCell>{formatDistanceToNow(new Date(log.rescueTime), { addSuffix: true })}</TableCell>
                  <TableCell className="text-right text-xs">
                    HR: {log.vitals.heartRate}, SpO2: {log.vitals.spo2}, T: {log.vitals.temperature}°C
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
