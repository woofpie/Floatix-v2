import { AlertCircle, Siren } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

type DistressAlertProps = {
  isDistress: boolean;
  alertMessage: string | null;
};

export default function DistressAlert({ isDistress, alertMessage }: DistressAlertProps) {
  if (!isDistress) return null;

  return (
    <Card className="fixed bottom-5 right-5 z-50 w-full max-w-md animate-pulse-red border-2 border-destructive bg-destructive/20 text-destructive-foreground shadow-2xl backdrop-blur-sm md:bottom-10 md:right-10">
      <CardContent className="p-4">
        <div className="flex items-center gap-4">
          <Siren className="h-12 w-12 shrink-0 animate-pulse text-destructive" />
          <div>
            <h2 className="text-xl font-bold text-destructive-foreground">
              DISTRESS ALERT
            </h2>
            <p className="text-sm text-destructive-foreground/80">
              {alertMessage || 'A distress signal has been activated. Immediate action required.'}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
