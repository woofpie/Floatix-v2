'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';

interface GpsInputDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (coords: { lat: number; lng: number }) => void;
  currentPosition: { lat: number; lng: number };
}

export default function GpsInputDialog({
  isOpen,
  onClose,
  onSave,
  currentPosition,
}: GpsInputDialogProps) {
  const [lat, setLat] = useState(currentPosition.lat.toString());
  const [lng, setLng] = useState(currentPosition.lng.toString());
  const { toast } = useToast();

  useEffect(() => {
    setLat(currentPosition.lat.toString());
    setLng(currentPosition.lng.toString());
  }, [currentPosition]);

  const handleSave = () => {
    const latNum = parseFloat(lat);
    const lngNum = parseFloat(lng);

    if (isNaN(latNum) || isNaN(lngNum)) {
      toast({
        variant: 'destructive',
        title: 'Invalid Input',
        description: 'Please enter valid numbers for latitude and longitude.',
      });
      return;
    }

    onSave({ lat: latNum, lng: lngNum });
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Update GPS Location</DialogTitle>
          <DialogDescription>
            Manually enter the latitude and longitude for the device.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="lat" className="text-right">
              Latitude
            </Label>
            <Input
              id="lat"
              value={lat}
              onChange={(e) => setLat(e.target.value)}
              className="col-span-3"
              type="number"
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="lng" className="text-right">
              Longitude
            </Label>
            <Input
              id="lng"
              value={lng}
              onChange={(e) => setLng(e.target.value)}
              className="col-span-3"
              type="number"
            />
          </div>
        </div>
        <DialogFooter>
          <Button type="button" variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" onClick={handleSave}>
            Update Location
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
