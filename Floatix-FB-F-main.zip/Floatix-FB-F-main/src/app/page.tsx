'use client';

import { useState, useEffect, useCallback, useRef } from 'react';
import type { Vitals, RescueLog, HistoricalData } from '@/lib/types';
import Header from '@/components/dashboard/Header';
import LiveVitals from '@/components/dashboard/LiveVitals';
import GpsMap from '@/components/dashboard/GpsMap';
import DataCharts from '@/components/dashboard/DataCharts';
import RescueLogComponent from '@/components/dashboard/RescueLog';
import DistressAlert from '@/components/dashboard/DistressAlert';
import { Button } from '@/components/ui/button';
import { Siren, Loader2, ZapOff, BatteryWarning, AlertTriangle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { customizeDistressAlert } from '@/ai/flows/customize-distress-alert';
import type { CustomizeDistressAlertInput } from '@/ai/flows/customize-distress-alert';
import GpsInputDialog from '@/components/dashboard/GpsInputDialog';

const initialVitals: Vitals = {
  heartRate: 78,
  spo2: 98,
  temperature: 36.5,
  acceleration: { x: 0.1, y: 0.2, z: 9.8 },
  motorSpeed: 5,
  battery: 82,
  connectivity: 'online',
  gps: { lat: 34.052235, lng: -118.243683 }, // Los Angeles
};

const initialRescueLogs: RescueLog[] = [
  {
    id: 'R001',
    name: 'John Doe',
    rescueTime: new Date(Date.now() - 1 * 60 * 60 * 1000).toISOString(),
    location: { lat: 34.053235, lng: -118.244683 },
    vitals: { heartRate: 85, spo2: 97, temperature: 36.8 },
  },
  {
    id: 'R002',
    name: 'Jane Smith',
    rescueTime: new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString(),
    location: { lat: 34.054235, lng: -118.245683 },
    vitals: { heartRate: 92, spo2: 96, temperature: 37.1 },
  },
];

const initialHistoricalData: HistoricalData = {
  heartRate: Array.from({ length: 7 }, (_, i) => ({ time: `${(6-i) * 5}m`, value: 75 + Math.random() * 10 })),
  temperature: Array.from({ length: 7 }, (_, i) => ({ time: `${(6-i) * 5}m`, value: 36.5 + Math.random() * 0.5 })),
  speed: Array.from({ length: 7 }, (_, i) => ({ time: `${(6-i) * 5}m`, value: 4 + Math.random() * 2 })),
};

export default function DashboardPage() {
  const [vitals, setVitals] = useState<Vitals>(initialVitals);
  const [rescueLogs, setRescueLogs] = useState<RescueLog[]>(initialRescueLogs);
  const [historicalData, setHistoricalData] = useState<HistoricalData>(initialHistoricalData);
  const [isDistress, setIsDistress] = useState(false);
  const [alertMessage, setAlertMessage] = useState<string | null>(null);
  const [isGeneratingAlert, setIsGeneratingAlert] = useState(false);
  const [isGpsDialogOpen, setIsGpsDialogOpen] = useState(false);

  const { toast } = useToast();
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    // Initialize audio on client
    if (typeof window !== 'undefined') {
      audioRef.current = new Audio('https://actions.google.com/sounds/v1/alarms/alarm_clock.ogg');
      audioRef.current.loop = true;
    }
  }, []);

  const clearDistress = useCallback(() => {
    setIsDistress(false);
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
  }, []);

  const handleDistress = useCallback(async (distressInput: CustomizeDistressAlertInput) => {
    setIsDistress(true);
    setIsGeneratingAlert(true);
    if (audioRef.current) {
      audioRef.current.play().catch(e => console.error("Error playing sound:", e));
    }
    try {
      const result = await customizeDistressAlert(distressInput);
      const generatedMessage = result.alertMessage;

      if (!generatedMessage) {
        throw new Error('AI did not return a message.');
      }

      setAlertMessage(generatedMessage);
      toast({
        variant: 'destructive',
        title: 'Distress Alert Processed',
        description: generatedMessage,
      });
    } catch (error) {
      console.error('Error customizing distress alert:', error);
      const fallbackMsg = 'A distress signal has been activated. Immediate action required.';
      setAlertMessage(fallbackMsg);
      toast({
        variant: 'destructive',
        title: 'Distress Signal Activated',
        description: fallbackMsg,
      });
    } finally {
      setIsGeneratingAlert(false);
    }
  }, [toast]);

  useEffect(() => {
    const interval = setInterval(() => {
      setVitals(prev => {
        const newVitals = {
          ...prev,
          heartRate: prev.heartRate + (Math.random() - 0.5) * 2,
          spo2: Math.min(100, Math.max(95, prev.spo2 + (Math.random() - 0.5) * 0.5)),
          temperature: prev.temperature + (Math.random() - 0.5) * 0.1,
          motorSpeed: Math.max(0, prev.motorSpeed + (Math.random() - 0.5) * 1),
          battery: Math.max(0, prev.battery - 0.1),
        };

        setHistoricalData(hPrev => ({
          heartRate: [...hPrev.heartRate.slice(1), { time: new Date().toLocaleTimeString(), value: newVitals.heartRate }].slice(-7),
          temperature: [...hPrev.temperature.slice(1), { time: new Date().toLocaleTimeString(), value: newVitals.temperature }].slice(-7),
          speed: [...hPrev.speed.slice(1), { time: new Date().toLocaleTimeString(), value: newVitals.motorSpeed }].slice(-7),
        }));

        return newVitals;
      });
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  const handleGpsUpdate = (newCoords: { lat: number; lng: number }) => {
    setVitals(prev => ({
      ...prev,
      gps: newCoords,
    }));
    toast({
      title: 'GPS Location Updated',
      description: `Map centered to Lat: ${newCoords.lat}, Lng: ${newCoords.lng}`,
    });
  };

  return (
    <div className="flex min-h-screen w-full flex-col">
      <Header onSetGps={() => setIsGpsDialogOpen(true)} />
      <main className="flex-1 p-4 md:p-8">
        <div className="container mx-auto max-w-screen-2xl">
          <div className="mb-6 flex flex-col items-start justify-between gap-4 md:flex-row md:items-center">
            <h2 className="text-3xl font-bold tracking-tight font-headline">Live Dashboard</h2>
            <div className="flex gap-2">
              {isDistress ? (
                  <Button variant="outline" onClick={clearDistress}>
                      Clear Distress
                  </Button>
              ) : (
                <>
                <Button variant="destructive" onClick={() => handleDistress({ distressType: 'manual' })} disabled={isGeneratingAlert}>
                    {isGeneratingAlert ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Siren className="mr-2 h-4 w-4" />}
                    Trigger Manual Distress
                </Button>
                 <Button variant="outline" size="icon" onClick={() => handleDistress({ distressType: 'sensorAnomaly', sensorData: 'Unusual vibration detected' })} title="Simulate Sensor Anomaly"><AlertTriangle/></Button>
                 <Button variant="outline" size="icon" onClick={() => handleDistress({ distressType: 'lowBattery' })} title="Simulate Low Battery"><BatteryWarning/></Button>
                 <Button variant="outline" size="icon" onClick={() => handleDistress({ distressType: 'connectivityIssue' })} title="Simulate Connectivity Issue"><ZapOff/></Button>
                </>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 gap-6">
            <LiveVitals vitals={vitals} />
            <DataCharts data={historicalData} />
            <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
              <GpsMap position={vitals.gps} />
              <RescueLogComponent logs={rescueLogs} />
            </div>
          </div>
        </div>
      </main>
      <DistressAlert isDistress={isDistress} alertMessage={alertMessage} />
      <GpsInputDialog
        isOpen={isGpsDialogOpen}
        onClose={() => setIsGpsDialogOpen(false)}
        onSave={handleGpsUpdate}
        currentPosition={vitals.gps}
      />
    </div>
  );
}
