export interface Vitals {
  heartRate: number;
  spo2: number;
  temperature: number;
  acceleration: { x: number; y: number; z: number };
  motorSpeed: number;
  battery: number;
  connectivity: 'online' | 'offline' | 'weak';
  gps: { lat: number; lng: number };
}

export interface RescueLog {
  id: string;
  name: string;
  rescueTime: string; // ISO string
  location: { lat: number; lng: number };
  vitals: {
    heartRate: number;
    spo2: number;
    temperature: number;
  };
}

export interface HistoricalDataPoint {
  time: string;
  value: number;
}

export interface HistoricalData {
  heartRate: HistoricalDataPoint[];
  temperature: HistoricalDataPoint[];
  speed: HistoricalDataPoint[];
}
