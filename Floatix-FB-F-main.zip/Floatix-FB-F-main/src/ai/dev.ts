import { config } from 'dotenv';
config();

import '@/ai/flows/summarize-rescue-logs.ts';
import '@/ai/flows/customize-distress-alert.ts';