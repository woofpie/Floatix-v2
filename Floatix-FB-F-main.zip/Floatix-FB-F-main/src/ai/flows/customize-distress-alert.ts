'use server';
/**
 * @fileOverview A Genkit flow that customizes the distress alert message based on the nature of the distress signal.
 *
 * - customizeDistressAlert - A function that processes the distress signal and returns a customized alert message.
 * - CustomizeDistressAlertInput - The input type for the customizeDistressAlert function.
 * - CustomizeDistressAlertOutput - The return type for the customizeDistressAlert function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const CustomizeDistressAlertInputSchema = z.object({
  distressType: z
    .enum(['manual', 'sensorAnomaly', 'lowBattery', 'connectivityIssue'])
    .describe('The type of distress signal received.'),
  sensorData: z
    .string()
    .optional()
    .describe('Additional sensor data related to the distress signal.'),
});
export type CustomizeDistressAlertInput = z.infer<typeof CustomizeDistressAlertInputSchema>;

const CustomizeDistressAlertOutputSchema = z.object({
  alertMessage: z
    .string()
    .describe('A customized alert message based on the distress signal type.'),
});
export type CustomizeDistressAlertOutput = z.infer<typeof CustomizeDistressAlertOutputSchema>;

export async function customizeDistressAlert(
  input: CustomizeDistressAlertInput
): Promise<CustomizeDistressAlertOutput> {
  // This bypasses the LLM for predefined static messages, ensuring reliability.
  let message = '';
  switch (input.distressType) {
    case 'manual':
      message = 'Manual distress signal activated by user. Immediate assistance required.';
      break;
    case 'sensorAnomaly':
      message = `Automatic Alert: ${input.sensorData || 'Unspecified sensor anomaly detected'}. Please investigate.`;
      break;
    case 'lowBattery':
      message = 'Automatic Alert: Low battery warning. Device power is critical.';
      break;
    case 'connectivityIssue':
      message = 'Automatic Alert: Connectivity lost with device. Attempting to re-establish connection.';
      break;
    default:
      message = 'An unknown distress signal has been activated. Immediate action required.';
      break;
  }
  return Promise.resolve({ alertMessage: message });
}
