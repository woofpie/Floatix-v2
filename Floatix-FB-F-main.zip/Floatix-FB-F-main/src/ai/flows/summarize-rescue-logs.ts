'use server';

/**
 * @fileOverview Summarizes rescue logs for a given time period.
 *
 * - summarizeRescueLogs - A function that summarizes rescue logs.
 * - SummarizeRescueLogsInput - The input type for the summarizeRescueLogs function.
 * - SummarizeRescueLogsOutput - The return type for the summarizeRescueLogs function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SummarizeRescueLogsInputSchema = z.object({
  logs: z.string().describe('The rescue logs to summarize.'),
  timePeriod: z
    .string() 
    .describe(
      'The time period for the rescue logs (e.g., daily, weekly).'
    ),
});

export type SummarizeRescueLogsInput = z.infer<
  typeof SummarizeRescueLogsInputSchema
>;

const SummarizeRescueLogsOutputSchema = z.object({
  summary: z.string().describe('A summary of the rescue logs.'),
});

export type SummarizeRescueLogsOutput = z.infer<
  typeof SummarizeRescueLogsOutputSchema
>;

export async function summarizeRescueLogs(
  input: SummarizeRescueLogsInput
): Promise<SummarizeRescueLogsOutput> {
  return summarizeRescueLogsFlow(input);
}

const summarizeRescueLogsPrompt = ai.definePrompt({
  name: 'summarizeRescueLogsPrompt',
  input: {schema: SummarizeRescueLogsInputSchema},
  output: {schema: SummarizeRescueLogsOutputSchema},
  prompt: `You are an expert supervisor reviewing rescue logs.

  Summarize the following rescue logs for the given time period. Identify any trends or areas needing improvement.

  Time Period: {{{timePeriod}}}
  Rescue Logs: {{{logs}}}
  Summary:`, 
});

const summarizeRescueLogsFlow = ai.defineFlow(
  {
    name: 'summarizeRescueLogsFlow',
    inputSchema: SummarizeRescueLogsInputSchema,
    outputSchema: SummarizeRescueLogsOutputSchema,
  },
  async input => {
    const {output} = await summarizeRescueLogsPrompt(input);
    return output!;
  }
);
